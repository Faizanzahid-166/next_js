## Table `ecommerce_store_products`

### Columns

| Name | Type | Constraints |
|------|------|-------------|
| `id` | `uuid` | Primary Unique |
| `name` | `text` |  |
| `category` | `text` |  Nullable |
| `price` | `numeric` |  |
| `stock` | `int4` |  |
| `description` | `text` |  Nullable |
| `image_url` | `text` |  Nullable |
| `created_at` | `timestamptz` |  Nullable |
| `product_no` | `int4` |  Unique |

## Table `carts`

### Columns

| Name | Type | Constraints |
|------|------|-------------|
| `id` | `uuid` | Primary |
| `user_id` | `text` |  Unique |
| `created_at` | `timestamptz` |  Nullable |

## Table `cart_items`

### Columns

| Name | Type | Constraints |
|------|------|-------------|
| `id` | `uuid` | Primary |
| `cart_id` | `uuid` |  Nullable |
| `product_id` | `uuid` |  Nullable |
| `user_id` | `text` |  |
| `quantity` | `int4` |  |
| `created_at` | `timestamptz` |  Nullable |

